package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaptopShopFinal2Application {

	public static void main(String[] args) {
		SpringApplication.run(LaptopShopFinal2Application.class, args);
	}

}
